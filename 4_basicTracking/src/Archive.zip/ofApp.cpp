#include "ofApp.h"

//--------------------------------------------------------------
void ofApp::setup(){
    
    gui.setup();
    gui.add(minArea.setup("circle minArea", 5, 3, 1024*768 * 0.01));
    gui.add(maxArea.setup("circle maxArea", 5, 3, 1024*768 * 0.5));
    gui.add(threshold.setup("threshold", 5, 0, 255));
    gui.add(debugOn.setup("debug", false));
    
    gui.loadFromFile("settings.xml");
    
    // inladen demo image
    testImage.load("test.JPG");

    float w = testImage.getWidth();
    float h = testImage.getHeight();
    
    colorImg.allocate(w,h);
    grayImage.allocate(w,h);
    
    ofSetCircleResolution(30);
    ofEnableAlphaBlending();
}



//--------------------------------------------------------------
void ofApp::update(){
    
    // omzetten van de image naar opencv
    colorImg.setFromPixels(testImage.getPixels());
    grayImage = colorImg;
    
    grayImage.invert();
    grayImage.threshold(threshold);
    
    contourFinder.findContours(grayImage, minArea, maxArea, 10, false);
    
    
}

//--------------------------------------------------------------
void ofApp::draw(){
    
    ofSetHexColor(0xffffff);
    
    colorImg.draw(0, 0);
    
    
    if(debugOn){
        ofSetHexColor(0xffffff);

        grayImage.draw(0,0);
        
        for (int i = 0; i < contourFinder.nBlobs; i++){
            ofSetColor(255, 255, 250);
            contourFinder.blobs[i].draw(0,0);
        }
    }
    

    for (int i = 0; i < contourFinder.nBlobs; i++){
        ofVec2f blobCenter = contourFinder.blobs[i].centroid;
       
        ofFill();

        ofSetColor(255, 20,200 ,120);
        ofDrawCircle(blobCenter,100);
    }

    
    gui.draw();
    
}

//--------------------------------------------------------------
void ofApp::keyPressed(int key){
}

//--------------------------------------------------------------
void ofApp::keyReleased(int key){
    
}

//--------------------------------------------------------------
void ofApp::mouseMoved(int x, int y ){
    
}

//--------------------------------------------------------------
void ofApp::mouseDragged(int x, int y, int button){
    
}

//--------------------------------------------------------------
void ofApp::mousePressed(int x, int y, int button){
    
}

//--------------------------------------------------------------
void ofApp::mouseReleased(int x, int y, int button){
    
}

//--------------------------------------------------------------
void ofApp::mouseEntered(int x, int y){
    
}

//--------------------------------------------------------------
void ofApp::mouseExited(int x, int y){
    
}

//--------------------------------------------------------------
void ofApp::windowResized(int w, int h){
    
}

//--------------------------------------------------------------
void ofApp::gotMessage(ofMessage msg){
    
}

//--------------------------------------------------------------
void ofApp::dragEvent(ofDragInfo dragInfo){ 
    
}
